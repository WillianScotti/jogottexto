var stage = 0;

function comecarJogo() {
  stage = 1;
  var story = document.getElementById("story");
  var btn = document.getElementsByTagName("button")[0];
  var imagem = document.getElementById("floresta.jpg");

  story.textContent =
    "Você sai da vila de Serenity em busca de aventuras. No caminho, encontra uma trilha misteriosa. O que você faz?";
  btn.textContent = "Seguir pela trilha";
  btn.setAttribute("onclick", "seguirTrilha()");
  imagem.src = "floresta.jpg";
}

function seguirTrilha() {
  stage = 2;
  var story = document.getElementById("story");
  var btn = document.getElementsByTagName("button")[0];
  var imagem = document.getElementById("floresta.jpg");

  story.textContent =
    "A trilha leva você a uma caverna escura. Você entra na caverna ou retorna para a vila?";
  btn.textContent = "Entrar na caverna";
  btn.setAttribute("onclick", "entrarCaverna()");
  imagem.src = "floresta.jpg";
}

function entrarCaverna() {
  stage = 3;
  var story = document.getElementById("story");
  var btn = document.getElementsByTagName("button")[0];
  var imagem = document.getElementById("floresta.jpg");

  story.textContent =
    "Dentro da caverna, você encontra um tesouro incrível! Você se torna uma lenda na região e vive o resto de seus dias como um herói.";
  btn.textContent = "Reiniciar";
  btn.setAttribute("onclick", "reiniciarJogo()");
  imagem.src = "floresta.jpg";
}
function escolherCaminho(caminho) {
  document.getElementById("game-container").innerHTML = `
      <h1>Jogo de Aventura na Selva</h1>
      <img src="selva.jpg" alt="Selva">
      <p>Você escolheu o caminho da ${caminho}.</p>
      <p>Explorando ${caminho}, você se depara com:</p>
      <ul>
          <li>Uma cachoeira majestosa.</li>
          <li>Uma caverna escura e sinistra.</li>
          <li>Uma ponte suspensa sobre um abismo profundo.</li>
      </ul>
      <p>O que você faz?</p>
      <button onclick="decisao('${caminho}', 'cachoeira')">Explorar a cachoeira</button>
      <button onclick="decisao('${caminho}', 'caverna')">Entrar na caverna</button>
      <button onclick="decisao('${caminho}', 'ponte')">Cruzar a ponte suspensa</button>
  `;
}

function decisao(caminho, escolha) {
  document.getElementById("game-container").innerHTML = `
      <h1>Jogo de Aventura na Selva</h1>
      <img src="selva.jpg" alt="Selva">
      <p>Você escolheu ${escolha}.</p>
      <p>Explorando mais fundo, você encontra:</p>
      <ul>
          <li>Um tesouro escondido.</li>
          <li>Uma tribo indígena amigável.</li>
          <li>Uma fera selvagem perigosa.</li>
      </ul>
      <p>O que você faz?</p>
      <button onclick="finalizar('${escolha}')">Investigar</button>
      <button onclick="escolherCaminho('${caminho}')">Voltar e escolher outro caminho</button>
  `;
}

function finalizar(resultado) {
  let mensagem;
  if (resultado === "tesouro") {
    mensagem =
      "Parabéns! Você encontrou o tesouro e completou sua aventura com sucesso!";
  } else if (resultado === "tribo") {
    mensagem =
      "A tribo indígena lhe recebe calorosamente e oferece sua amizade. Você completa sua aventura em segurança!";
  } else if (resultado === "fera") {
    mensagem =
      "Infelizmente, você foi atacado pela fera selvagem e sua aventura chega a um fim trágico.";
  }
  document.getElementById("game-container").innerHTML = `
      <h1>Jogo de Aventura na Selva</h1>
      <img src="selva.jpg" alt="Selva">
      <p>${mensagem}</p>
      <button onclick="location.reload()">Jogar Novamente</button>
  `;
}
